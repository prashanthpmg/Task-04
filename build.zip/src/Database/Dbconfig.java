package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Dbconfig {
     public Connection getconnection()
    {
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/task04", "root", "");
            return con;
            
        }
         catch (ClassNotFoundException | SQLException e) 
        {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public java.sql.Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}